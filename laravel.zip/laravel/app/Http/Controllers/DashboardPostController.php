<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DashboardPostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('Dashboard.posts.index',[
            'posts' => Post::all()
        ]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Dashboard.posts.create');
    }

    /** 
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'title' => 'required|max:20',
            'category' => 'required|max:20',
            'image' =>'image|file|min:2'
        ]); 
        $validatedData['id']= auth()->user()->id;
        $validatedData['image']= $request->file('image')->store('post-image');
        Post::create($validatedData);
        return redirect('/dashboard/post')->with('success', 'New Post added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $Post)
    {
        return view('Dashboard.posts.show',[
            'posts'=> $Post
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Post  $Post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $Post)
    {
        return view('Dashboard.posts.edit',[
            'posts'=> $Post
        ]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Post  $Post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Post $Post)
    {
            $validatedData = $request->validate([
            'title' => 'required|max:20',
            'subtitle' => 'required|max:150',
            'image' =>'image|file|min:10'
        ]); 
        $validatedData['id']= auth()->user()->id;
        Post::where('id', $Post->id)
              ->update($validatedData);
        return redirect('/dashboard/post')->with('success', 'Post Updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Post  $Post
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $Post)
    {
        if($Post->image){
            Storage::delete($Post->image);
        }
        $Post->delete();
        return redirect('/dashboard/post')->with('success', 'Post Delete!');
    }
}
