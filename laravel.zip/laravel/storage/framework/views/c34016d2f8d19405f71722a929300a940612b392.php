<div class="container-fluid pt-5">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('/dashboard') ? 'active' : ''); ?>" aria-current="page" href="#">
              <span data-feather="home" width="15" class="float-left mr-2"></span>
              Dashboard
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link " href="#">
              <span data-feather="file" width="15" class="float-left mr-2"></span>
              Orders
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="shopping-cart" width="15" class="float-left mr-2"></span>
              Products
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="users" width="15"class="float-left mr-2"></span>
              Customers
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="bar-chart-2" width="15"class="float-left mr-2"></span>
              Reports
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="layers" width="15"class="float-left mr-2"></span>
              Integrations
            </a>
          </li>
        </ul>
        </ul>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
             <li class="nav-item">
              <a class="nav-link"href="route('logout')" onclick="event.preventDefault(); this.closest('form').submit();">
              <span data-feather="log-out" width="15"class="float-left mr-2"></span>
                Log out
              </a>
            </li>
        </form>
        </ul>
      </div>
    </nav>
 </div>
</div><?php /**PATH C:\xampp\htdocs\onedream_laravelbreeze\laravel\resources\views/Dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>