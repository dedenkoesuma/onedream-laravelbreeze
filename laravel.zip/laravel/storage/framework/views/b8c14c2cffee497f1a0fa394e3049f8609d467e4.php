
<?php $__env->startSection('page'); ?>

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-5 pb-2 mb-3 border-bottom">
          <h1 class="h2">My Post</h1>
        </div>
<div class="col-lg-8 mt-5"> 
 <form method="post" action="/dashboard/post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="title" class="form-label">Title</label>
      <input type="text" class="form-control" id="title"  name="title"placeholder="Input Title">
    </div>
     <div class="mb-3">
      <label for="excerpt" class="form-label">Excerpt</label>
      <textarea class="form-control" id="excerpt" name="excerpt" rows="3"></textarea>
    </div>
    <div class="mb-3">
      <label for="Body" class="form-label">Body</label>
      <textarea class="form-control" id="Body" name="body" rows="3"></textarea>
    </div>
    <div class="mb-3">
    <label for="image" class="form-label">Post Image</label>
    <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image" name="image">
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="Invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  </div>
  <button type="submit" class="btn btn-primary" style="background-color: #0f143b;">Submit</button>
 </form>
</div>

  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onedream_laravelbreeze\laravel\resources\views/dashboard/posts/create.blade.php ENDPATH**/ ?>