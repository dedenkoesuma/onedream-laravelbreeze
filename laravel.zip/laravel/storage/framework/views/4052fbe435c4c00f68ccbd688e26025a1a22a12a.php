

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3>Are you sure you want to delete this post?</h3>
        <form action="<?php echo e(route('dashboard.post.destroy', $posts)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
            <a href="<?php echo e(route('dashboard.post.index')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onedream_laravelbreeze\laravel\resources\views/Dashboard/posts/delete.blade.php ENDPATH**/ ?>