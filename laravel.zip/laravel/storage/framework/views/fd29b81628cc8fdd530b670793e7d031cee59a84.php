
<?php $__env->startSection('container'); ?>
      <a class="btn btn-primary mt-4 align-items-center d-flex m-0 col-lg-3" href="/dashboard/post">
                <span data-feather="arrow-left" width="15"class="me-3" ></span>
          Back to all my post
      </a>
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-5 pb-2 mb-3 border-bottom">
          <h1 class="h2">Edit My Post</h1>
        </div>

      <?php if(session()->has('success')): ?>
      <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

      </div>
      <?php endif; ?>

      <div class="col-lg-8 mt-5"> 
       <form method="post" action="/dashboard/post/<?php echo e($posts->id); ?>" enctype="multipart/form-data">
        <?php echo method_field('put'); ?>
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title"  name="title"placeholder="Input Title" required autofocus value="<?php echo e(old('title', $posts->title)); ?>">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="Invalid-feedback">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="mb-3">
            <label for="subtitle" class="form-label">Subtitle</label>
            <input class="form-control <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="subtitle" name="subtitle" rows="3" placeholder="Input Subtitle" required autofocus value="<?php echo e(old('subtitle', $posts->subtitle)); ?>">
            <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="Invalid-feedback">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="mb-3">
          <label for="image" class="form-label">Post Image</label>
          <?php if($posts->image): ?>
          <img src="<?php echo e(asset('storage/'.$posts->image)); ?>" class="img-preview img-fluid mb-3 col-sm-5">
          <?php else: ?>
          <img class="img-preview img-fluid mb-3 col-sm-5">
          <?php endif; ?>

          <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-1 p-1" type="file" id="image" name="image" onchange="previewImage()" >
          <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="Invalid-feedback">
              <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        </div>        
        <button type="submit" class="btn btn-primary" style="background-color: #0f143b;">Submit</button>
       </form>
      </div>

  <?php $__env->stopSection(); ?>



<?php echo $__env->make('Dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onedream_laravelbreeze\laravel\resources\views/Dashboard/posts/edit.blade.php ENDPATH**/ ?>